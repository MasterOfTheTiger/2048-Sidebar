window.open("https://addons.mozilla.org/en-US/firefox/addon/2048-webextension-sidebar/");
